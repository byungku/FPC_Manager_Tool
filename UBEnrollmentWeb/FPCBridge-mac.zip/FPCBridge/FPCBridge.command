#!/bin/bash
# Double-click to start FPCBridge (PC/SC bridge for the FPC Manager web app).
cd "$(dirname "$0")" || exit 1

# Files unpacked from a downloaded zip are quarantined by macOS; clear it for the bridge binaries.
xattr -d com.apple.quarantine FPCBridge-mac-arm64 FPCBridge-mac-intel 2>/dev/null

if [ "$(sysctl -n hw.optional.arm64 2>/dev/null)" = "1" ]; then
  exec ./FPCBridge-mac-arm64 "$@"
else
  exec ./FPCBridge-mac-intel "$@"
fi
